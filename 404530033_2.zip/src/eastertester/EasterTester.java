package eastertester;

import java.util.Scanner;

public class EasterTester {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Easter easter = new Easter();
		System.out.println("Enter a year to calculate Ester Sunday :");
		Scanner t = new Scanner(System.in);
		int input = getResult(t);
		System.out.println(easter.calculateEaster(input));				
	}

	private static int getResult(Scanner t) {
		// TODO Auto-generated method stub
		return t.nextInt();
	}

}
