package tictactoe;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class TicTacToe implements ActionListener{
	private int[][] winCombinations = new int[][] {{0, 1, 2}, {3, 4, 5}, {6, 7, 8}, {0, 3, 6}, {1, 4, 7}, {2, 5, 8}, {0, 4, 8}, {2, 4, 6}};
	private JFrame window = new JFrame("Tic-Tac-Toe");
	private JButton buttons[] = new JButton[9];
	private int count = 0;
	private String letter = "";
	private boolean win = false;
	private static int startCount =0;
	JMenuBar menu = new JMenuBar();
	JMenuItem newGame = new JMenuItem("New Game"),
	instr = new JMenuItem("Instructions"),
	exit = new JMenuItem("Exit"),
	name = new JMenuItem("Change Name"); 
	static String x = "X";
	static String y = "Y";
	public TicTacToe(){
		window.setSize(360,360);
		window.setLocationRelativeTo(null);
		window.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		window.setLayout(new GridLayout(3,3));
		for(int i=0; i<=8; i++){
		buttons[i] = new JButton();
		window.add(buttons[i]);
		buttons[i].addActionListener(this);
		}
		menu.add(newGame);
		menu.add(name);
		menu.add(instr);
		menu.add(exit);

		name.addActionListener(this);
		newGame.addActionListener(this);
		exit.addActionListener(this);
		instr.addActionListener(this);
		window.setJMenuBar(menu);
		window.setVisible(true);	
	}
	public void setName(){
		x = JOptionPane.showInputDialog(null, "Enter Name of player O: ", "", 1);
		y = JOptionPane.showInputDialog(null, "Enter Name of player X: ", "", 1);
		if(x==null){
		x = "O";
		}
		if(y==null){
		y = "X";
		}
		if(x.length()==0){
		x = "O";
		}
		if(y.length()==0){
			y = "X";
		}
		JOptionPane.showMessageDialog(null, "Your names have been set\nReady to tic tac toe  ","START!!!",JOptionPane.INFORMATION_MESSAGE);
	}
	public void actionPerformed(ActionEvent a){
		Object source = a.getSource();
		if(source == newGame)	{
			int answer = JOptionPane.showConfirmDialog(null, "Your current game will not be saved...\nContinue Anyways??", "Do you want to start a new game?", JOptionPane.YES_NO_OPTION);
		if (answer == JOptionPane.YES_OPTION){
			this.clearIt(); }
		}
		else if(source == name){
			this.setName();
		}
		else if(source == instr){
			JOptionPane.showMessageDialog(null, "Be the first player to get 3 X/O in a row! (horizontally, diagonally, or vertically)","Instructions",JOptionPane.INFORMATION_MESSAGE);
		}
		else if(source == exit){
			int answer = JOptionPane.showConfirmDialog(null, "Do you want to exit??", "EXIT", JOptionPane.YES_NO_OPTION);
		if (answer == JOptionPane.YES_OPTION){
			JOptionPane.showMessageDialog(null, "Thanks! " + x+ " and " + y + " for playing Tic-Tac-Toe G_G");
			System.exit(0);	}
		}
		else{
			count++;
		if(count % 2 == 0){
			letter = "X";
		}
		else{
			letter = "O";
		}
		JButton pressedButton = (JButton)source;
		pressedButton.setText(letter);
		pressedButton.setEnabled(false);
		for(int i=0; i<=7; i++){
			if( buttons[winCombinations[i][0]].getText().equals(buttons[winCombinations[i][1]].getText()) &&
			buttons[winCombinations[i][1]].getText().equals(buttons[winCombinations[i][2]].getText()) &&
			buttons[winCombinations[i][0]].getText() != ""){
			win = true; }
		}
		if(win == true)	{
			if(letter.equals("O"))
			letter = x;
			else
			letter = y;
			JOptionPane.showMessageDialog(null, letter + " wins the game!");
			int answer = JOptionPane.showConfirmDialog(null, "Start", "Do you want to start a new game?", JOptionPane.YES_NO_OPTION);
		if (answer == JOptionPane.YES_OPTION){
			this.clearIt();
		}
		else{
			JOptionPane.showMessageDialog(null, "Thanks! " + x+ " and " + y + " for playing G_G");
			System.exit(0); }
		}
		else if(count == 9 && win == false)	{
			JOptionPane.showMessageDialog(null, "The game was tie!");
			int answer = JOptionPane.showConfirmDialog(null, "Start", "Do you want to start a new game?", JOptionPane.YES_NO_OPTION);
		if (answer == JOptionPane.YES_OPTION){
			this.clearIt();
		}
		else{
			JOptionPane.showMessageDialog(null, "Thanks! " + x+ " and " + y + " for playing G_G");
			System.exit(0);	}
		     }
	    }
	}
	public void clearIt(){
		window.setVisible(false);
		this.startIt();
		}
		public void startIt(){
			new TicTacToe();
		}
		public static void main(String[] args){
			TicTacToe starter = new TicTacToe();
			starter.setName(); }
		}