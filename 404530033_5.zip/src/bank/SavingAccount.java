package bank;

public class SavingAccount {
double rate;
	
	SavingAccount(int accountNumber,double initialBalance,double R){
		this.rate=R;
	}
	void addInterest(double B){				
		double interest = B * this.rate / 100;			
		if(interest <= 0)	System.out.println("interest wrong!");
		else	super.deposit(interest);												
	}

}
