package bank;

public class BankTester {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
Bank TheBank=new Bank();
		
		TheBank.addCheckingAccount(1001, 0);
		TheBank.addSavingsAccount(1002, 0, 10);
		TheBank.addCheckingAccount(1003, 0);	
		TheBank.addSavingsAccount(1004, 0, 10);
		
		TheBank.deposit(1001,500);	
		TheBank.deposit(1001,250);		
		TheBank.deposit(1001,300);
		TheBank.deposit(1001,50);
		TheBank.deposit(1001,5000);
		TheBank.withdraw(1001,500);
		TheBank.withdraw(1001,500);
		TheBank.withdraw(1001,500);
		TheBank.withdraw(1001,500);
		TheBank.withdraw(1001,500);
		TheBank.deductFees(1001);		
		TheBank.closeAccount(1001);		
		
		TheBank.deposit(1002,2500);		
		TheBank.deposit(1002,1500);		
		TheBank.withdraw(1002,2000);	
		TheBank.withdraw(1002,500);	
		TheBank.addInterest(1002);		
		TheBank.deposit(1002,4000);			
		TheBank.suspendAccount(1002);	
				
		TheBank.deposit(1003,1000);		
		TheBank.deposit(1003,100);		
		TheBank.withdraw(1003,250);		
		TheBank.deposit(1003,750);		
		TheBank.deposit(1004,750);				
		TheBank.transfer(1003,1004,800);	 	
														
		TheBank.summarizeAccountTransactions(1001);
		TheBank.summarizeAccountTransactions(1002);
		TheBank.summarizeAccountTransactions(1003);
		TheBank.summarizeAccountTransactions(1004);
		
		TheBank.summarizeAllAccounts();
	}

}
