package bank;
import java.util.ArrayList;
public class BankAccount {
	String state;
	int accountNumber;
	private double balance;
	private ArrayList<Double> TransactionList = null;
	public BankAccount() {
		this(-1,-1);
	}
	public BankAccount(int anAccountNumber) {
		this(anAccountNumber,0);
	}
	public BankAccount(int anAccountNumber, double initialBalance) {
		this.state = "open";
		this.accountNumber = anAccountNumber;
		this.balance = initialBalance;
		this.TransactionList = new ArrayList<Double>();
	}
	boolean isOpen() {
		if(this.state.equalsIgnoreCase("open"))
			return true;
		else{
			return false;
		}
	}
	boolean isSuspended() {
		if(this.state.equalsIgnoreCase("suspended"))
			return true;
		else{
			return false;
		}
	}
	boolean isClosed() {
		if(this.state.equalsIgnoreCase("closed"))
			return true;
		else{
			return false;
		}
	}
	void reOpen() {
		this.state = "open";
	}
	void suspend(){
		this.state = "suspended";
	}
	void close(){
		this.state = "closed";
	}
	void deposit(double amount) {
		if(this.isOpen() && amount > 0){
		this.balance += amount;
		addTransaction(amount);
		}
		else{
			System.err.println("transcation:" + this.accountNumber + "deposit occurs.");
		}
	}
	void withdraw(double amount) {
		if(this.isOpen() && amount > 0 && amount <= this.balance ){
		this.balance -= amount;
		addTransaction(0 - amount);
		}
		else{
			System.err.println("transcation:" + this.accountNumber + "withdraw occurs.");
		}
	}
	void addTransaction(double amount) {
		this.TransactionList.add(amount);
	}
	String getTransactions() {
		StringBuffer sb = new StringBuffer();
		for (int i = 0;i < this.TransactionList.size(); i++){
			sb.append((i + 1) + ":" + this.TransactionList.get(i) + "\n");
		}
		return sb.toString();
	}
	public double getBalance(){
		return this.balance;
	}
	int getaccountNumber(){
		return this.accountNumber;
	}
	String getStatus(){
		if(isOpen()){
			return "open";
		}
		else if(isSuspended()){
			return "suspended"; 
		}
		else	return "closed";
	}
	public boolean equals(double a){
		if(Math.abs(this.balance-a) <= 0.1){
			return true;
		}
		else return false;
	}
	int retrieveNumberOfTransactions() {
		return this.TransactionList.size();
	}

}
